import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div className='k'>
                        <p className='a'>Nome:</p>
                        <p className='b'>João</p>
                        <p className='c'>Senha: *</p>
                        <p className='d'>Email:</p> 
                        <p className='e'>melo@gmail.com</p>
                        <p className='f'>CPF:</p>
                        <p className='g'>12345678900</p>
                        <p className='h'>Endereço:</p> 
                        <p className='i'>Travessa Agenor José Rodrigues Pereira, 546, Rocinha Rio de Janeiro, RJ, Brasil, 22451-545</p>
                        <p className='j'>Alterar Endereço</p>
                    </div>
                </div>
        
        </main>
    )
}