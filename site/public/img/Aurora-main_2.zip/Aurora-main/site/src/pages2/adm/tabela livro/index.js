import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';



export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
            <div className='posição'>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
                
                <div>
                    <div>
                        <input type=""/>
                        <img src="" alt=""/>
                    </div>

                    <div>
                        <div>
                            <img src="" alt=""/>
                            <p>The Boys o Nome do Jogo</p>
                            <p>E-Book</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Cronicas de Narnia</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Eu sou Malala</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>As aventuras de Mike</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Nascida do Fogo</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Reliqua</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Foxcraft: A magia da raposa</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>JUIZ DREDD</p>
                            <p>livro</p>
                            <input type=""/>
                        </div>
                    </div>

                </div>

            </div>
        </main>
    )
}

