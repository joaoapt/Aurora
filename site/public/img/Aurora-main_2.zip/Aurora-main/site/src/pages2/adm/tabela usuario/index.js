import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';



export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
            <div className='posição'>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>

                <div>
                    <input type=""/>
                    <div>
                        <p>Identificação</p>
                        <p>Nome</p>
                        <p>telefone</p>
                        <p>envio</p>
                        <p>valor</p>
                    </div>
                    <div>
                        <p>13144</p>
                        <p>Brunexxx</p>
                        <p>40028922</p>
                        <p>04/01/05</p>
                        <p>R$ 300,00</p>
                    </div>
                    <div>
                        <p>13144</p>
                        <p>João </p>
                        <p>40028922</p>
                        <p>04/01/05</p>
                        <p>R$ 99,00</p>
                    </div>
                    <div>
                        <p>13144</p>
                        <p>Mr.Monk</p>
                        <p>40028922</p>
                        <p>04/01/05</p>
                        <p>R$ 150,00</p>
                    </div>
                    <div>
                        <p>13144</p>
                        <p>Big-Smoke</p>
                        <p>40028922</p>
                        <p>04/01/05</p>
                        <p>R$ 1,00</p>
                    </div>
                    <div>
                        <p>13144</p>
                        <p>Aline</p>
                        <p>40028922</p>
                        <p>04/01/05</p>
                        <p>R$ 400,00</p>
                    </div>
                </div>

            </div>
        </main>
    )
}