import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <div>
                            <p>Boleto</p>
                            <p>Código de Barras</p>
                            <img src="" alt=""/>
                            <p>001929686355430089</p>
                            <p>enviar</p>
                        </div>
                        <div>
                            <p>resume</p>
                            <hr/>
                            <p>Nome:                   Culio Ferraz</p>
                            <p>CPF:                 546.789.908-99</p>
                            <p>Telefone:          (11) 967890987</p>
                            <p>Total da conpra R$ 198,00</p>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}