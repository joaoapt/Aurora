import './index.scss';

export default function Index() {
    return(
        <main className='page-home'>
        
                <div>
                    <div>
                        <div className='g'>
                            <p className='a'>Cartão de credito</p>
                            <p className='b'>Codigo do Boleto:</p>
                            <input type=""/>
                            <p className='c'>Número:</p>
                            <input type=""/>
                            <div>
                                <p className='d'>Validade:</p>
                                <input type=""/>
                                <p className='e'>Validade:</p>
                                <input type=""/>
                            </div>
                            <p className='f'>enviar</p>
                        </div>
                        <div className='h'>
                            <p className='i'>resume</p>
                            <hr/>
                            <p className='j'>Nome:                   Culio Ferraz</p>
                            <p className='k'>CPF:                 546.789.908-99</p>
                            <p className='l'>Telefone:          (11) 967890987</p>
                            <p className='m'>Total da conpra R$ 198,00</p>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}