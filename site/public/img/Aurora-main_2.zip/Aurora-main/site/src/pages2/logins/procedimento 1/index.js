import './index.scss';

export default function Index() {
    return(
        <main className='page-home'>
                <div>
                    <div className='d'>
                        <p className='a'>Nova senha</p>
                        <p className='b'>email</p>
                        <input type="text"/>
                        <input type=""/>
                        <p className='c'>proximo</p>
                    </div>
                </div>
        
        </main>
    )
}