import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';


export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <div>
                            <p>Pedido Realizado dia 15/08/2022</p>
                            <img src="" alt=""/>
                        </div>
                        <div>
                            <p>Prazo estimado para a entrega dia 22/08/2022</p>
                            <img src="" alt=""/>
                        </div>
                        <div>
                            <p>enviado dia 17/08/2022</p>
                            <img src="" alt=""/>
                        </div>
                        <div>
                            <p>enviado dia 17/08/2022</p>
                            <img src="" alt=""/>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}