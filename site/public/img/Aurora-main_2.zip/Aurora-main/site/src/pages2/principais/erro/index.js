import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <p>oops!!</p>
                        <img src="" alt=""/>
                        <p>voltar</p>
                    </div>
                </div>
        
        </main>
    )
}