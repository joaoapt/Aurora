import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <div className='a'>
                            <p className='b'>Livro: As Cronicas de Narnia Data: 09/09/2022</p>
                            <p className='c'>Entregue com sucesso</p>
                        </div>
                        <div className='d'>
                            <p className='e'>Livro: Nacida do Fogo Data: 09/09/2022</p>
                            <p className='f'>Pagamento Concluído</p>
                        </div>
                        <div className='g'>
                            <p className='h'>Livro: Nacida do Fogo Data: 09/09/2022</p>
                            <p className='i'>Enviado para Entrega</p>
                        </div>
                        <div className='j'>
                            <p className='k'>Audio Book: The boys Data: 09/09/2022</p>
                            <p className='l'>Link</p>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}