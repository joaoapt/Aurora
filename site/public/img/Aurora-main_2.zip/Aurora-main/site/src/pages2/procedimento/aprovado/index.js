import './index.scss';

export default function Index() {
    return(
        <main className='page-home'>
        
                <div>
                    <div className='d'>
                        <img/>
                        <br/>
                        <img/>
                    </div>

                    <div className='f'>
                        <div className='e'>
                            <p className='a'>Sua Compra foi efetuada com sucesso</p>
                            <img src="" alt=""/>
                        </div>
                        <p className='b'>Número do pedido: 34567</p>
                        <p className='c'>Valor Total: R$ 99,00</p>
                    </div>
                </div>
        
        </main>
    )
}