import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <p>Preferemcia de Pagamento</p>
                        <div>
                            <img src="" alt=""/>
                            <p>Boleto Bancário</p>
                        </div>
                        <div>
                            <p>ou</p>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>Cartão de Credito</p>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}