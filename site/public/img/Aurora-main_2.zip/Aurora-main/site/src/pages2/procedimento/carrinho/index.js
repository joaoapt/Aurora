import './index.scss';
import Menu from '../../../components/admin/menu';
import Cabecalho from '../../../components/admin/cabecalho';

import { Gif } from '../../../components/animação/GifAnimatons';

export default function Index() {
    return(
        <main className='page-home'>
            <Menu selecionado='home'/>
                <div className='cabecalho'>
                    <Cabecalho/>
                </div>
        
                <div>
                    <div>
                        <div>
                            <p>Livro</p>
                            <p>Nome</p>
                            <p>Entrega</p>
                            <p>Quantidade</p>
                            <p>Preço</p>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>As Cronicas de Nárnia</p>
                            <p>é necessário mais informações</p>
                            <input type="text"/>
                            <p>R$ 99,00</p>
                        </div>
                        <div>
                            <img src="" alt=""/>
                            <p>A Crônica do Fogo</p>
                            <p>é necessário mais informações</p>
                            <input type="text"/>
                            <p>R$ 99,00</p>
                        </div>
                        <div>
                            <p>Resumo</p>
                            <hr/>
                            <p>Total      R$ 198,00</p>
                            <p>Finalizar Compra</p>
                        </div>
                    </div>
                </div>
        
        </main>
    )
}