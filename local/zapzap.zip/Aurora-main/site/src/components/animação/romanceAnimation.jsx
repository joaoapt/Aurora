import React from "react";
import Lottie from "react-lottie";

import roma from '../../animacao/romance.json';

export const Romance = () => {
        const sd = {
            loop: true,
            autoplay:true,
            animationData: roma
        }
   return <Lottie options={sd} width={380} />
} 