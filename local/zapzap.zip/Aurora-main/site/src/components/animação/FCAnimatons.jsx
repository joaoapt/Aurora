import React from "react";
import Lottie from "react-lottie";

import GifJson from '../../animacao/estudar.json'

export const FC = () => {
        const ds = {
            loop: true,
            autoplay:true,
            animationData: GifJson
        }
        return <Lottie options={ds} width={350} />
}