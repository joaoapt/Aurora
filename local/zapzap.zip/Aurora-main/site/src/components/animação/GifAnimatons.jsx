import React from "react";
import Lottie from "react-lottie";

import GifJson from '../../animacao/gif.json'

export const Gif = () => {
        const ds = {
            loop: true,
            autoplay:true,
            animationData: GifJson
        }
        return <Lottie options={ds} width={900} />
}   