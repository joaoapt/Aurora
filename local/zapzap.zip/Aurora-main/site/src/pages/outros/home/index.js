import './index.scss';
import Buscar from '../../../components/outros/busca';
import Rodape from '../../../components/outros/rodape';
import Card from '../../../components/carrocel/card';
import Produto from '../../../components/carrocel/produto';
import Categoria from '../../../components/outros/categoria';
import { Link } from 'react-router-dom';

// import { Romance } from '../../../components/animação/romanceAnimation';
// import { FC } from '../../../components/animação/FCAnimatons';

export default function Index () {
    return(
        <div className='pag-home'>
            <div>
            <nav><Buscar/></nav>
                <div className='conteudo'>
                    <div><Card/></div>
                    <div className='cate'>
                        <Categoria/> 
                    </div>
                    <div>
                        <h4>Aventura</h4>
                        <div className='aaa'>
                            <Produto/>
                        </div>
                    </div>
                    <div>
                        <h4>Filosofia</h4>
                        <div className='aaa'>
                            <Produto/>
                        </div>
                    </div>
                    <Link to='/produto/vil' className='img'>
                        <img className="propaganda" src="./img/propaganda.png" alt="propaganda"/>
                    </Link>
                    <div>
                        <h4>Sociologia</h4>
                        <div className='aaa'>
                            <Produto/>
                        </div>
                    </div>
                    <div className='box-quadrado'>
                        <div className='quadrado'>
                            <h3>Livro de Romance</h3>
                        
                        </div>
                        <div className='quadrado'>
                            <h3>Livro de Sci-Fi</h3>
                            
                        </div>
                    </div>
                </div>
                <footer><Rodape/></footer>
            </div>
        </div>
    )
}