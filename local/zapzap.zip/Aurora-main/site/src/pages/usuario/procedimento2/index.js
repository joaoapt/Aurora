import './index.scss';

export default function Index() {
    return(
        <main className='page-home'>
                <div>
                    <div className='f'>
                        <h1 className='a'>Nova Senha</h1>
                        <p className='b'>Nova Senha</p>
                        <input type=""/>
                        <p className='c'>Confirme a Nova Senha</p>
                        <input type=""/>
                        <p className='d'>Voltar</p>
                        <p className='e'>Proximo</p>
                    </div>
                </div>
        </main>
    )
}